set serveroutput on
set autoprint off


-- condition whith null values look at ep17-handling null values.png
-- handing null with the expression  
-- var is null 