SET SERVEROUTPUT ON;


-- avoid using varible name like table column name
-- you can use DML cammands => INSERT, UPDATE, DELETE, MERGE