set serveroutput on
set autoprint off

-- examples of cursors
-- look ep30.sql
-- when update => commit;