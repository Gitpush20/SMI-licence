/*

mutating table 
like ex96
using table

type table_name is table of varchar(2)
index by pls_integer;



*/