set serveroutput on
set autoprint off

-- chache store cache into memory for next use
-- paralled for use 4 processes to process the data

-- 1 Cache and paralled are only in oracle enterprise editions
-- also the DBA make changes in these values
-- parameter shared_pool_size
-- parameter result_cache_max_size
-- parameter result_cache_mode

-- watch the video