package Exam2017.T;

public class B  extends  A{

    public void m(){
        System.out.println("B");
    }

}
