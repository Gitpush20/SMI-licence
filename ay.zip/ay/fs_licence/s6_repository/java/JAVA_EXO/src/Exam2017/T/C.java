package Exam2017.T;

public class C extends B {

    /*public void m(){
        System.out.println("C");
    }*/

}
