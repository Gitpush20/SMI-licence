package Exam2017.Ex02;

public class B extends A{

    private int x;

    public int getX(){
        return x;
    }

    public void f(){
        x += 5;
    }

}
