package Exam2017.T;

public class Main {



    public static void main(String[] args){
        A a = new C();

        a.m();
    }

}
