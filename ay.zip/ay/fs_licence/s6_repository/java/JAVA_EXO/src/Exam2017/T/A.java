package Exam2017.T;

public class A {

    public void m(){
        System.out.println("A");
    }

}
