package Exam2017.Ex02;

public class A {

    public int x;

    A(){
        f();
    }

   public void f(){
       x += 8;
   }

}
