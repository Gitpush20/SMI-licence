package TEST;

public class Test {

    int a = 5;

    public Test(int a){
        this.a = a;
    }

    public int getA(){
        return a;
    }

}
