package TP3.Entreprise;

public interface ARisque {

    double PrimeMensuelle = 2000;

}
