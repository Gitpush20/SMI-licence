public class Class1 {

    int x;
    int y;

    Class1(int x, int y){
        this.x = x;
        this.y = y;
    }

    Class1(){
        x = 0;
        y = 0;
    }

    int sum(){
        return x + y;
    }

}
