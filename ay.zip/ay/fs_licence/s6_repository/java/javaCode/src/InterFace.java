public class InterFace implements Class{
    @Override
    public void talk() {
        System.out.println("I am talking");
    }
}
