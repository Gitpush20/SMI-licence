public interface Class{

    void talk();

}