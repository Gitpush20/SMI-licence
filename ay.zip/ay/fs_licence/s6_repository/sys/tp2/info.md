ex04
    **kill -l**
    *on redéfinie le comportement des 64 signaux définis sous UNIX*
    *on exclut les signaux 9 et 19 plus le 32 et le 33*
    *https://chromium.googlesource.com/chromiumos/docs/+/master/constants/signals.md*