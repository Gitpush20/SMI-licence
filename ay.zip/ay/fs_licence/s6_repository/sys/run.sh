if gcc "$1/"$2".c"; then
    ./a.out
fi