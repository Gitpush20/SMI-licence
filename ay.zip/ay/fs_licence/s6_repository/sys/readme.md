## links

*drive s6*
https://drive.google.com/drive/u/1/folders/1uwGe5tGYBesUEjgvMlB5U2mk3XYghDfe