ex1
On observe l'exécution de deux processus en parallèle
Père et le Fils

ex2
Les variables d'environnement sont héritées par le fils par
duplication.

ex3
Toute instruction a l'extérieur du Fils et du Père est exécutée deux Fois : une par le Fils et une par le Père