target=$1$2".cpp"

if g++ -std=c++11 $target; then

    ./a

fi