//ayoub-ben
#include <iostream>

int main(){

    int *adi = NULL;
    double *add = NULL;

    adi = new int;
    add = new double[100];

   
    return 0;
}